import { Noir } from "@noir-lang/noir_js";
import { ethers } from "ethers";
import { UltraHonkBackend } from "@aztec/bb.js";
import { fileURLToPath} from "url";
import path from "path";
import fs from "fs";

// Configuracao do caminho
const __dirname = path.dirname(fileURLToPath(import.meta.url));
// arquivo do circuito noir.nr
const circuitoEndereco = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../circuitos/target/circuitos.json");
//const circuito = fs.readFileSync(circuitoEndereco, "utf-8")
const circuito = JSON.parse(fs.readFileSync(circuitoEndereco, 'utf-8'));

export default async function generateProof() {
    const inputsArray = process.argv.slice(2);
    try {
        // inicializa o noir com o circuito
        const noir = new Noir(circuito);

        // inicializa o backend usando o bytecode do circuito
        const bb = new UltraHonkBackend(circuito.bytecode, {threads: 1});

        // Definicao dos inputs
        const inputs = {
            // Entradas privadas
            cpf: "12345678901",
            titulo: "987654321",
            voto: "7",
            segredo: "9988776655",
            merkle_proof: Array(20).fill("0"), // Preencher com vizinhos 
            is_left: Array(20).fill(true), // deve corresponder a posicao na arvore
            // Entradas publicas
        }
        // 1 - Gerar a witness
        // noir verifica se os inputs satisfazem o circuito
        // executa o circuito com as entradas para criar a witness
        const { witness } = await noir.execute(inputs);

        // 2 - Gerar a prova usando o Ultrahonk
        // deixa o output limṕo
        const originalLog = console.log;
        console.log = () => {};

        // keccak: true gera um prova compativel com o verificador Solidity padrao
        const { proof } = await bb.generateProof(witness, {keccak: true});
        console.log = originalLog;

        // 3 - Codificar para o formato 'bytes' do Solidity
        // o contrato espera 'bytes proof', que o ethers.js codifica
        const proofEncoded = ethers.AbiCoder.defaultAbiCoder().encode(
            ["bytes"],
            [proof]
        );

        return proofEncoded;

        // retorna a prova
    } catch(error) {
        console.log("Erro na geração da prova:", error);
        throw error;
    }    
}

// Executa o script
(
    async () => {
        try{
            const encodedProof = await generateProof();
            // Stdout para que outros scripts possam capturar
            process.stdout.write(encodedProof);
            process.exit(0);
        } catch(error) {
            process.exit(1);
        }            
    }
)();